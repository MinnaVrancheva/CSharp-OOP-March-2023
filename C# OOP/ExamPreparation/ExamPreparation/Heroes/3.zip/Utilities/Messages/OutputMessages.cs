﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Heroes.Utilities.Messages
{
    internal class OutputMessages
    {
        public const string SuccessfullyAddedKnight = "Successfully added Sir {0} to the collection.";
        public const string SuccessfullyAddedBarbarian = "Successfully added Barbarian {0} to the collection.";
    }
}
