﻿using Heroes.Models.Contracts;
using Heroes.Repositories;
using Heroes.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Text;

namespace Heroes.Models.Weapons
{
    public abstract class Weapon : IWeapon
    {
        private string name;
        private int durability;
        private WeaponRepository weapons;

        public Weapon(string name, int durability)
        {
            Name = name;
            Durability = durability;
            this.weapons = new WeaponRepository();
        }

        public string Name
        {
            get { return name; }
            private set
            {
                if(string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(string.Format(ExceptionMessages.InvalidWeaponType));
                }
                name = value;
            }
        }

        public int Durability
        {
            get { return durability; }
            private set
            {
                if(value < 0)
                {
                    throw new ArgumentException(string.Format(ExceptionMessages.DurabilityBelowZero));
                }
                durability = value;
            }
        }

        public int DoDamage()
        {
            this.Durability -= 1;

            if (Durability <= 0)
            {
                return 0;
            }

            if (weapons.Models.GetType().Name == nameof(Mace))
            {
                return 25;
            }
            else
            {
                return 20;
            }
        }
    }
}
