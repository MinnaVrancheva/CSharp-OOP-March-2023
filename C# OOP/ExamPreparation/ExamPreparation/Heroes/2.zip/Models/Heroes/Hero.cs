﻿using Heroes.Repositories;
using Heroes.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Text;

namespace Heroes.Models.Contracts.Heroes
{
    public abstract class Hero : IHero
    {
        private string name;
        private int health;
        private int armour;
        private IWeapon weapon;
        //private HeroRepository heroes;
        private bool isAlive;

        public Hero(string name, int health, int armour)
        {
            Name = name;
            Health = health;
            Armour = armour;
            Weapon = weapon;
            IsAlive = true;
        }

        public string Name
        {
            get { return name; }
            private set
            {
                if(string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(ExceptionMessages.InvalidHeroName);
                }
                name = value;
            }
        }

        public int Health
        {
            get { return health; }
            private set
            {
                if(value < 0)
                {
                    throw new ArgumentException(ExceptionMessages.TooLowHeroHealth);
                }
                health = value;
            }
        }

        public int Armour
        {
            get { return armour; }
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException(ExceptionMessages.TooLowHeroArmour);
                }
                armour = value;
            }
        }

        public IWeapon Weapon
        {
            get { return weapon; }
            private set
            {
                if(value == null)
                {
                    throw new ArgumentException(ExceptionMessages.WeaponIsNull);
                }
                weapon = value;
            }
        }

        public bool IsAlive
        {
            get { return isAlive; }
            private set
            {
                if(health < 0)
                {
                    isAlive = false;
                }
                //isAlive = value;
            }
        }

        public void AddWeapon(IWeapon weapon)
        {
            Weapon = weapon;
        }

        public void TakeDamage(int points)
        {
            //points = this.armour + this.health;
            
            //this.Health -= weapon.DoDamage();

            this.Armour -= points;

            if(armour <= 0 )
            {
                armour = 0;
                this.Health -= points;

                if(health < 0)
                {
                    health = 0;
                    isAlive = false;
                }
            }
        }
    }
}
