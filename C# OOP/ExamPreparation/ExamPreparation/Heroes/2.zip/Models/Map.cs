﻿using Heroes.Models.Contracts;
using Heroes.Models.Contracts.Heroes;
using Heroes.Repositories;
using Heroes.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Heroes.Models
{
    public class Map : IMap
    {
        private IRepository<IHero> heroes;

        public Map()
        {
            this.heroes = new HeroRepository();
        }
        public string Fight(ICollection<IHero> players)
        {
            players = heroes.Models.GetType() as ICollection<IHero>;
            List<IHero> barbarians = new List<IHero>();
            List<IHero> knights = new List<IHero>();
            int barbariansInitialCount = barbarians.Count;
            int knightsInitialCount = knights.Count;

            if (players.GetType().Name == "Barbarian")
            {
                barbarians.AddRange(players);
            }
            else
            {
                knights.AddRange(players);
            }

            while (barbarians.Count > 0 && knights.Count > 0)
            {
                foreach (var knight in knights)
                {
                    if (knight.IsAlive)
                    {
                        foreach (var barbarian in barbarians)
                        {
                            //int points = knight.Weapon.DoDamage();
                            barbarian.TakeDamage(knight.Weapon.DoDamage());
                        }
                    }
                }

                foreach (var barbarian in barbarians)
                {
                    if (barbarian.IsAlive)
                    {
                        foreach (var knight in knights)
                        {
                            //int points = barbarian.Weapon.DoDamage();
                            knight.TakeDamage(knight.Weapon.DoDamage());
                        }
                    }
                }
            }

            if (knights.Count > 0)
            {
                return $"The knights took {knightsInitialCount - knights.Count} casualties but won the battle.";
            }
            else
            {
                return $"The knights took {barbariansInitialCount - barbarians.Count} casualties but won the battle.";
            }
        }
    }
}
