﻿namespace FoodShortage;

public interface IIdentifier
{
    string Id { get; }
}
