﻿namespace BirthdayCelebrations;

public interface IIdentifier
{
    string Id { get; }
}
