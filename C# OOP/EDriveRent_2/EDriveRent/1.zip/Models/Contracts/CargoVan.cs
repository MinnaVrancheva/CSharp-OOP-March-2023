﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDriveRent.Models.Contracts
{
    public class CargoVan : Vehicle
    {
    }
}
