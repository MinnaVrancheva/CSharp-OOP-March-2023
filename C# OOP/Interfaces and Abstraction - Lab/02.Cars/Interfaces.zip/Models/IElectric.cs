﻿namespace Cars.Models
{
    public interface IElectric
    {
    }
}