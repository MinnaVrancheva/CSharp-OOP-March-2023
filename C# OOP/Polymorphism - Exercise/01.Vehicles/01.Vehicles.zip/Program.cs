﻿using Vehicles.Core;
using Vehicles.Core.Interfaces;

IEngine engine = new Engine();
engine.Run();
